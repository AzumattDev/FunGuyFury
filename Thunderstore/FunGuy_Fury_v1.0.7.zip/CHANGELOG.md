### Changelog (Latest Listed First)

---
<details>
<summary><b>v1.0.7</b></summary>

> - Update for Ashlands.
</details>

<details>
<summary><b>v1.0.6</b></summary>

> - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here.
</details>

<details>
<summary><b>v1.0.5</b></summary>

> - Update for the latest Valheim version. (0.217.22)
</details>

<details>
<summary><b>v1.0.4</b></summary>

> - Update for the latest Valheim version. (0.217.14 - Hildir Update)
</details>

<details>
<summary><b>v1.0.3</b></summary>

> - Update for the latest Valheim version.
</details>

<details>
<summary><b>v1.0.2</b></summary>

> - Some spawning fixes.
> - Update to Latest ItemManager
</details>

<details>
<summary><b>v1.0.1</b></summary>

> - README fix
</details>

<details>
<summary><b>v1.0.0</b></summary>

> - Initial Release
</details>